//
//  main.m
//  RunThisTarget
//
//  Created by liusr on 2022/5/24.
//

#import <Foundation/Foundation.h>
#import <objc/runtime.h>
#import <objc/message.h>

@interface Animal : NSObject
@end

@interface Person : NSObject
@end

@implementation Animal
@end

@implementation Person
@end

@interface Person(PerAddition)
@property (nonatomic, strong) NSString *cate_name;
+ (void)life;
- (void)work;
@end

const NSString *kPersonName = @"kPersonName";
@implementation Person(PerAddition)
+ (void)life {}
- (void)work {}

- (void)setCate_name:(NSString *)cate_name{
    /**
      * object: 关联的对象
      * key: 类似字典的形式 key value 绑定
      * 把value通过key,
      * policy: 用policy这种策略关联给object;
      */
    objc_setAssociatedObject(self, &kPersonName, cate_name, OBJC_ASSOCIATION_COPY_NONATOMIC);
}

- (NSString *)cate_name {
    return objc_getAssociatedObject(self, &kPersonName);
}
@end

@interface Animal(AniAddition)
- (void)play;
@end

@implementation Animal(AniAddition)
- (void)play {}
@end

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // insert code here...
        NSLog(@"Hello, World!");
    }
    return 0;
}
